#!/data/data/com.termux/files/usr/bin/env python
o#insert your termux pkg info
# you pkg name ej : hello_example

TERMUX_PKG_NAME=""

# you pkg version ej : 1.0.0

oTERMUX_PKG_VERSION=""

# you home or source page ej: https://mypackage.github.org

TERMUX_PKG_HOMEPAGE=""

# you description ej : this example for hello world

TERMUX_PKG_DESCRIPTION=""

# you pkg mantainer ej: Yisus7u7 <jesuspixel5@gmail.com>

TERMUX_PKG_MAINTAINER=""

# your pkg depends ej: python, php, coreutils 

TERMUX_PKG_DEPENDS=""

# your pkg size ej: 2040 
# Note: the value must be equal to Kb

TERMUX_PKG_SIZE=""

# you arch for package ej: arm
# note : use all for all phones

TERMUX_PKG_ARCH="all"

# end


