#!/data/data/com.termux/files/usr/bin/env python3
#insert your termux pkg info
# you pkg name ej : hello_example

TERMUX_PKG_NAME="prueba"

# you pkg version ej : 1.0.0

TERMUX_PKG_VERSION="1.0.2"

# you home or source page ej: https://mypackage.github.org

TERMUX_PKG_HOMEPAGE="https://prueba.com"

# you description ej : this example for hello world

TERMUX_PKG_DESCRIPTION="prueba de funcionalidad"

# you pkg mantainer ej: Yisus7u7 <jesuspixel5@gmail.com>

TERMUX_PKG_MAINTAINER="@Yisus7u7"

# your pkg depends ej: python, php, coreutils 

TERMUX_PKG_DEPENDS="python, wget"

# your pkg size ej: 2040 
# Note: the value must be equal to Kb

TERMUX_PKG_SIZE="11"

# you arch for package ej: arm
# note : use all for all phones

TERMUX_PKG_ARCH="all"

# end


